import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('')
    # model.load('yolov8n.pt') # loading pretrain weights
    #
    model.train(data='',
                epochs=300,  # (int) 训练的周期数
                cos_lr=True,  # 使用余弦学习调度器
                amp=False,
                batch=32,
                imgsz=640,
                optimizer='SGD',  # using SGD
                )